package hello.itemservice.exception.exhandler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ApiExceptionControllerV2 {
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler({IllegalArgumentException.class, RuntimeException.class})
	public ErrorResult illegalExHandler(IllegalArgumentException e) {
		log.error("[exceptionHandler] ex", e);
		return new ErrorResult("BAD", e.getMessage());
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler
	public ErrorResult userExHandler(Exception e){
		log.error("[exceptionHandler] ex", e);
		return new ErrorResult("EX", "서버 내부오류");
	}
	
	
	@GetMapping("/api2/members/{id}")
	public MemberDto getMember(@PathVariable("id") String id) {
		
		if(id.equals("ex")) {
			throw new RuntimeException("잘못된 사용자");
		}
		
		if(id.equals("bad")) {
			throw new IllegalArgumentException("잘못된 입력값");
		}
		
		return new MemberDto(id, "hello " + id);
		
	}   
	
	
	@Data
	@AllArgsConstructor
	static class MemberDto {
		private String memberId;
		private String name;
		
	}
	
}









