package hello.itemservice.exception.servlet;

import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.ErrorPage;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component 
public class WebserverCustomizer implements 
	WebServerFactoryCustomizer<ConfigurableWebServerFactory>{
	
	@Override
	public void customize(ConfigurableWebServerFactory factory) {
		
		ErrorPage errorPage404 = new ErrorPage(HttpStatus.NOT_FOUND, "/error-page/404");
		ErrorPage errorPage500 = new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, "/error-page/500");
		ErrorPage errorPageEx = new ErrorPage(RuntimeException.class, "/error-page/500");
		
		factory.addErrorPages(errorPage404, errorPage500, errorPageEx);
		
	}
	
	/*
	 * [서블릿 오류페이지 작동원리]
	 * Exception(예외)발생해서 response.sendError()가 호출되었을 때
	 * 지정된 오류페이지를 찾아 보여줌 
	 * 
	 * [예외 발생 흐름]
	 * 컨트롤러 예외발생 -> 인터셉터 -> 서블릿 -> 필터 -> was(톰캣) > response.sendError()
	 * 
	 * 
	 * 오류발생시 기본으로 /error 하위에 있는
		화면을 찾아서 반환함
		
		스프링부트가 자동등록한 
		BasicErrorController 가  /error 에 있는 
		오류 화면을 스캔함
		
		BasicErrorController 가
		뷰 화면 찾는 순서
		
		1. 뷰템플릿 
		- resources/templates/error/500.html
		2. 정적리소스(static, public)
		- resources/static/error/400.html
		3. 적용대상이 없을때 뷰이름 error.html
		- resources/templates/error.html

	 * 
	 * 
	 * */
	
	
	
}
