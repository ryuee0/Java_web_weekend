package jpabook.jpashop;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import jakarta.transaction.Transactional;
import jpabook.jpashop.domain.Member;
import jpabook.jpashop.repository.MemberRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
public class MemberRepositoryTest {
	@Autowired
	MemberRepository repository;
	
	@Test
	@Transactional
	@Rollback(false)
	public void test() {
		Member member = new Member();
		member.setName("memberA");
		Long savedId = repository.save(member);
		
		log.info("{}", member.getName());
		log.info("{}", savedId);
		
	}
	
}
