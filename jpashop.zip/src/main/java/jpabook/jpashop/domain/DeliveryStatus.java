package jpabook.jpashop.domain;

// 배송상태
public enum DeliveryStatus {
	READY, COMP // 준비, 배송
}
