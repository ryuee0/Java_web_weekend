package jpabook.jpashop.domain;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

// 회원 엔티티
@Entity
@Getter @Setter
public class Member {
	
	@Id @GeneratedValue
	@Column(name = "member_id")
	private Long id;
	
	private String name;
	
	@OneToMany(mappedBy = "member") 
	// 두 엔티티의 관계에서 메인이 되는 엔티티를 mappedby에 넣어준다고 보면됨
	private List<Order> orders = new ArrayList<>();
	
}











