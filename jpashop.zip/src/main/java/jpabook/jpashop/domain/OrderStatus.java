package jpabook.jpashop.domain;

// 주문상태
public enum OrderStatus {
	ORDER, CANCEL
}
