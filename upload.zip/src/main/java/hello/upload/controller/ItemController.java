package hello.upload.controller;

import java.nio.file.FileStore;

import org.springframework.stereotype.Controller;

import hello.upload.domain.ItemRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

// 과제 : 아래의 객체들 활용하여, 컨트롤러 1,2,3 구현 
// ItemForm, UploadFile, FileStore, ItemRepository

@Slf4j
@Controller
@RequiredArgsConstructor
public class ItemController {
	private final ItemRepository itemRepository;
	private final FileStore fileStore;
	
	// 1. 등록폼 
	// getmapping("/items/new")
	// return "item-form";
	
	// 2. 등록폼에서 데이터 저장하고, 저장한 화면으로 리다이렉트
	// postmapping("/items/new")
	// return "redirect:/items/{itemId}";
	
	// 3. 등록한 상품+첨부파일 보여주기
	// getmapping("/item/{id}")
	// return "item-view";
	
}
